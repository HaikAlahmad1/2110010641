/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListTable;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataPayment {
    private ArrayList <String> amount;
    
    public dataPayment (){
        amount = new ArrayList <String>();
    }
    public void insertamount (String isi){
        this.amount.add(isi);
    }
    public ArrayList getRecordamount (){
        return this.amount;
    }
        
    
    
}
