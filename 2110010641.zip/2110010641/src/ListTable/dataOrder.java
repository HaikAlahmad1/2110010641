/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListTable;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataOrder {
    private ArrayList<String> date;
    private ArrayList<String> status;
    
    public dataOrder (){
        date = new ArrayList<String> ();
        status = new ArrayList<String> ();    
    }
    public void insertdate (String isi){
        this.date.add(isi);
    }
    public ArrayList getRecorddate (){
       return this.date;
    }
    public void insertstatus (String isi){
        this.status.add(isi);
    }
    public ArrayList getRecordstatus (){
        return this.status;
    }
  
    
}
