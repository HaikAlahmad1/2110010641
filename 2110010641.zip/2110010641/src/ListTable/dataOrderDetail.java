/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListTable;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataOrderDetail {
    
    private ArrayList <String> quantity;
    private ArrayList <String> taxStatus;
    
    public dataOrderDetail (){
        quantity = new ArrayList <String>();
        taxStatus = new ArrayList <String>();
    }
    public void insertquantity (String isi){
        this.quantity.add(isi);
    }
    public ArrayList getRecordquantity (){
        return this.quantity;
    }
    public void inserttaxStatus (String isi){
        this.taxStatus.add(isi);
    }
    public ArrayList getRecordtaxStatus (){
        return this.taxStatus;
    }
}
