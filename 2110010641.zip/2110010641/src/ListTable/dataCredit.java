/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListTable;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataCredit {
    private ArrayList <String> number;
    private ArrayList <String> type;
    private ArrayList <String> expDate;
    
    public dataCredit (){
        number = new ArrayList <String>();
        type = new ArrayList <String>();
        expDate = new ArrayList <String>();
    }
    public void insertnumber (String isi){
        this.number.add(isi);
    }
    public ArrayList getRecordnumber (){
        return this.number;
    }
    public void inserttype (String isi){
        this.type.add(isi);
    }
    public ArrayList getRecordtype (){
        return this.type;
    }
    public void insertexpDate (String isi){
        this.expDate.add(isi);
    }
    public ArrayList getRecordexpDate (){
        return this.expDate;
    }
}
