/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListTable;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataCheck {
    private ArrayList<String> name;
    private ArrayList<String> bank;
    
    public dataCheck(){
    name = new ArrayList<String>();
    bank = new ArrayList<String>();
    }
    public void insertname(String isi){
        this.name.add(isi);
    }
    public ArrayList getRecordname(){
        return this.name;        
    }
    public void insertbank (String isi){
        this.bank.add(isi);
    }
    public ArrayList getRecordbank(){
       return this.bank;
    }
}
