/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListTable;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataCostumer {
    
    private ArrayList<String> name;
    private ArrayList<String> addrees;
    
    public dataCostumer () {
    name = new ArrayList<String>()  ;
    addrees = new ArrayList<String>(); 
    }
    public void insertname (String isi){
        this.name.add(isi);
    }
    public ArrayList getRecordname () {
        return this.name;
    }
    public void insertaddrees (String isi){
        this.addrees.add(isi);
    }
    public ArrayList getRecordaddrees (){
        return this.addrees;
    }
    
}
