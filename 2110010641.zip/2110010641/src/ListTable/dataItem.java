/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ListTable;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class dataItem {
    private ArrayList <String> shippingWeightDescription;
    private ArrayList <String> getPrinceForQuantityGetWeight;
    
    public dataItem (){
        shippingWeightDescription = new ArrayList <String>();
        getPrinceForQuantityGetWeight = new ArrayList <String>();
    }
    public void insertshippingWeightDescription (String isi){
        this.shippingWeightDescription.add(isi);
    }
    public ArrayList getRecordshippingWeightDescription (){
        return this.shippingWeightDescription;
    }
    public void insertgetPrinceForQuantityGetWeight (String isi){
        this.getPrinceForQuantityGetWeight.add(isi);
    }
    public ArrayList getRecordgetPrinceForQuantityGetWeight (){
        return this.getPrinceForQuantityGetWeight;
    }
    
}
