/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg2110010641;


import MembershipGym.*;
import ListTable.*;
import Form.*;
/**
 *
 * @author User
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//    System.out.println("Method Overload");
//        Customer objku = new Customer();
//    System.out.println("Data Customer: " +objku.dataCustomer("HaikalAhmad ", "Cendana"));
//    
//        Payment objku2 = new Payment();
//    System.out.println("Data Payment: " +objku2.dataPayment("Rp30Juta"));
//    
//        Order objku3 = new Order();
//    System.out.println("Data Order: " +objku3.dataOrder("12 mei 2023 ", "aktif"));
//    
//        OrderDetail objku4 = new OrderDetail();
//    System.out.println("Data OrderDetail: " +objku4.dataOrderDetail("Standar ", "Mt"));
//    
//        item objku5 = new item();
//    System.out.println("Data item: " +objku5.dataitem(" 12 ", "15"));
//    
//        Credit objku6 = new Credit();
//    System.out.println("Data Credit: " +objku6.dataCredit(" 01 ", "amount "," 12 maret 2023"));
//    
//        Cash objku7 = new Cash();
//    System.out.println("Data Cash: " +objku7.dataCash("Rp30Juta"));
//    
//        Check objku8 = new Check();
//    System.out.println("Data Check: " +objku8.dataCheck("Haikal Ahmad  ", "BRI"));
//    
//    System.out.println("");
//    
//    System.out.println("Constructor Overload");
//    
//    Customer objku9 = new Customer("HaikalAhmad ", "Cendana");
//    System.out.println("Data Customer: " +objku9.dataCustomer());
//    
//        Payment objku10 = new Payment("Rp30Juta");
//    System.out.println("Data Payment: " +objku10.dataPayment());
//    
//        Order objku11 = new Order("12 mei 2023 ", "aktif");
//    System.out.println("Data Order: " +objku11.dataOrder());
//    
//        OrderDetail objku12 = new OrderDetail("Standar ", "Mt");
//    System.out.println("Data OrderDetail: " +objku12.dataOrderDetail());
//    
//        item objku13 = new item(" 12 ", "15");
//    System.out.println("Data item: " +objku13.dataitem());
//    
//        Credit objku14 = new Credit(" 01 ", "amount "," 12 maret 2023");
//    System.out.println("Data Credit: " +objku14.dataCredit());
//    
//        Cash objku15 = new Cash("Rp30Juta");
//    System.out.println("Data Cash: " +objku15.dataCash());
//    
//        Check objku16 = new Check("Haikal Ahmad  ", "BRI");
//    System.out.println("Data Check: " +objku16.dataCheck());
//    
 
//        dataCash cashTendered = new dataCash();
//        cashTendered.insertCashTendered("Dolar");
//        cashTendered.insertCashTendered("Rupiah");
//        System.out.println(cashTendered.getRecordcashTendered().get(0));
//        
//        dataCheck name = new dataCheck();
//        name.insertname("Haikal");
//        name.insertname("Lana");
//        System.out.println(name.getRecordname().get(1));
//        
//        dataCheck bank = new dataCheck();
//        bank.insertbank("BRI");
//        bank.insertbank("BCA");
//        System.out.println(bank.getRecordbank().get(0));
        
        
//        dataCostumer name = new dataCostumer();
//        name.insertname("Nama Pendek");
//        name.insertname("Nama Panjang");
//        System.out.println(name.getRecordname().get(1));
//                
//        dataCostumer addrees = new dataCostumer ();
//        addrees.insertaddrees("12132434");
//        addrees.insertaddrees("1131333");
//        System.out.println(addrees.getRecordaddrees().get(0));
//        
//        dataOrder date = new dataOrder();
//        date.insertdate("12 desember 2023");
//        date.insertdate("7 agustus 2023");
//        System.out.println(date.getRecorddate().get(1));
//        
//        dataOrder status= new dataOrder();
//        status.insertstatus("Aktif");
//        status.insertstatus("Tidak Aktif");
//        System.out.println(status.getRecordstatus().get(0));
//        
//          dataCredit number = new dataCredit();
//          number.insertnumber("12");
//          number.insertnumber("13");
//          System.out.println(number.getRecordnumber().add(1));
//          
//          dataCredit type = new dataCredit();
//          type.inserttype("12 kali bayar");
//          type.inserttype("5 kali bayar");
//          System.out.println(type.getRecordtype().get(1));
//          
//          dataCredit expDate =new dataCredit();
//          expDate.insertexpDate("Aktif");
//          expDate.insertexpDate("Tidak Aktif");
//          System.out.println(expDate.getRecordexpDate().get(0));
          
          
//          dataOrderDetail quantity = new dataOrderDetail(); 
//          quantity.insertquantity("jumlah Keseluruhan");
//          quantity.insertquantity("Jumlah Belakangan");
//          System.out.println(quantity.getRecordquantity().get(0));
////          
//          dataOrderDetail taxStatus = new dataOrderDetail();
//          taxStatus.inserttaxStatus("Termasuk Pajak");
//          taxStatus.inserttaxStatus("Belum Termasuk pajak");
//          System.out.println(taxStatus.getRecordtaxStatus().get(1));

//            dataPayment amount = new dataPayment();
//            amount.insertamount("Jumlah Keseluruhan");
//            System.out.println(amount.getRecordamount().get(0));
            
//          dataItem shippingWeightDescription= new dataItem();
//          shippingWeightDescription.insertshippingWeightDescription("jumlah Keseluruhan");
//          shippingWeightDescription.insertshippingWeightDescription("Jumlah Belakangan");
//          System.out.println(shippingWeightDescription.getRecordshippingWeightDescription().get(0));
//          
//          dataItem getPrinceForQuantityGetWeight=new dataItem();
//          getPrinceForQuantityGetWeight.insertgetPrinceForQuantityGetWeight("15");
//          getPrinceForQuantityGetWeight.insertgetPrinceForQuantityGetWeight("16");
//          System.out.println(getPrinceForQuantityGetWeight.getRecordgetPrinceForQuantityGetWeight().get(1));
//            
            new FormUtama().setVisible(true);
    }
    
    
    
    
    
}
